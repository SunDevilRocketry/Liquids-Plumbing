#Total Pressure Loss for SDR Liquid Rocket Engine Plumbing Circuit

#Sun Devil Rocketry Liquids (Plumbing)
#Created by Brendan Graves, Luke Spindel, and Malik Labban 06/29/2022
#Based off code by Patrick Imper 04/01/2020 and Brian Terasaki 9/18/21

#Google Sheets:
#https://docs.google.com/spreadsheets/d/1aUvMaiao6TR8Dw6xj9iu2XItyr9r5BN45mVLPCEwi44/edit#gid=0

import math
import gspread

sa = gspread.service_account(filename="deltapressure-357319-74df02360843.json")
sh = sa.open("Delta Pressure")
wks = sh.worksheet("Sheet2")

deltaP_Lox = [0,0,0,0,0,0]
deltaP_K = [0,0,0,0,0,0]
o_length = [0,0,0,0,0,0]
k_length = [0,0,0,0,0,0]

#-----------------------------------------------------

#CHECK LOCATION AND ASSIGN VARIABLES

for i in range(6):
  # At Location 1:
  if i == 0:
    sumL_LOx = float(wks.acell('B2').value) # Sum of the length of plumbing LOx (m)
    sumH_LOx = float(wks.acell('D3').value) # Sum of the changes in height of plumbing LOx (m)
    o_couplings = float(wks.acell('D4').value) # Total couplings up to location LOx
    o_90s = float(wks.acell('D5').value) # Total 90° bends up to location LOx (R/D > 1)
    o_teethrough = float(wks.acell('D6').value) # Number of tee-through fittings LOx (does not account for tube couplings)
    sumL_K = float(wks.acell('C2').value) # Sum of the length of plumbing Ker (m)
    sumH_K = float(wks.acell('E3').value) # Sum of the changes in height of plumbing Ker (m)
    k_couplings = float(wks.acell('E4').value) # Total couplings up to location Ker
    k_90s = float(wks.acell('E5').value) # Total 90° bends up to location Ker (R/D > 1)
    k_teethrough = float(wks.acell('E6').value) # Number of tee-through fittings Ker (does not account for tube couplings)
  # At Location 2:
  elif i == 1:
    sumL_LOx = float(wks.acell('B9').value) # Sum of the length of plumbing (m)
    sumH_LOx = float(wks.acell('D10').value) # Sum of the changes in height of plumbing (m)
    o_couplings = float(wks.acell('D11').value) # Total couplings up to location LOx
    o_90s = float(wks.acell('D12').value) # Total 90° bends up to location LOx (R/D > 1)
    o_teethrough = float(wks.acell('D13').value) # Number of tee-through fittings LOx (does not account for tube couplings)
    sumL_K = float(wks.acell('C9').value) # Sum of the length of plumbing Ker (m)
    sumH_K = float(wks.acell('E10').value) # Sum of the changes in height of plumbing Ker (m)
    k_couplings = float(wks.acell('E11').value) # Total couplings up to location Ker
    k_90s = float(wks.acell('E12').value) # Total 90° bends up to location Ker (R/D > 1)
    k_teethrough = float(wks.acell('E13').value) # Number of tee-through fittings Ker (does not account for tube couplings)
  # At Location 3:
  elif i == 2:
    sumL_LOx = float(wks.acell('B16').value) # Sum of the length of plumbing (m)
    sumH_LOx = float(wks.acell('D17').value) # Sum of the changes in height of plumbing (m)
    o_couplings = float(wks.acell('D18').value) # Total couplings up to location LOx
    o_90s = float(wks.acell('D19').value) # Total 90° bends up to location LOx (R/D > 1)
    o_teethrough = float(wks.acell('D19').value) # Number of tee-through fittings LOx (does not account for tube couplings)
    sumL_K = float(wks.acell('C16').value) # Sum of the length of plumbing Ker (m)
    sumH_K = float(wks.acell('E17').value) # Sum of the changes in height of plumbing Ker (m)
    k_couplings = float(wks.acell('E18').value) # Total couplings up to location Ker
    k_90s = float(wks.acell('E19').value) # Total 90° bends up to location Ker (R/D > 1)
    k_teethrough = float(wks.acell('E20').value) # Number of tee-through fittings Ker (does not account for tube couplings)
  # At Location 4:
  elif i == 3:
    sumL_LOx = float(wks.acell('B23').value) # Sum of the length of plumbing (m)
    sumH_LOx = float(wks.acell('D24').value) # Sum of the changes in height of plumbing (m)
    o_couplings = float(wks.acell('D25').value) # Total couplings up to location LOx
    o_90s = float(wks.acell('D26').value) # Total 90° bends up to location LOx (R/D > 1)
    o_teethrough = float(wks.acell('D27').value) # Number of tee-through fittings LOx (does not account for tube couplings)
    sumL_K = float(wks.acell('C23').value) # Sum of the length of plumbing Ker (m)
    sumH_K = float(wks.acell('E24').value) # Sum of the changes in height of plumbing Ker (m)
    k_couplings = float(wks.acell('E25').value) # Total couplings up to location Ker
    k_90s = float(wks.acell('E26').value) # Total 90° bends up to location Ker (R/D > 1)
    k_teethrough = float(wks.acell('E27').value) # Number of tee-through fittings Ker (does not account for tube couplings)
  # At Location 5:
  elif i == 4:
    sumL_LOx = float(wks.acell('B30').value) # Sum of the length of plumbing (m)
    sumH_LOx = float(wks.acell('D31').value) # Sum of the changes in height of plumbing (m)
    o_couplings = float(wks.acell('D32').value) # Total couplings up to location LOx
    o_90s = float(wks.acell('D33').value) # Total 90° bends up to location LOx (R/D > 1)
    o_teethrough = float(wks.acell('D34').value) # Number of tee-through fittings LOx (does not account for tube couplings)
    sumL_K = float(wks.acell('C30').value) # Sum of the length of plumbing Ker (m)
    sumH_K = float(wks.acell('E31').value) # Sum of the changes in height of plumbing Ker (m)
    k_couplings = float(wks.acell('E32').value) # Total couplings up to location Ker
    k_90s = float(wks.acell('E33').value) # Total 90° bends up to location Ker (R/D > 1)
    k_teethrough = float(wks.acell('E34').value) # Number of tee-through fittings Ker (does not account for tube couplings)
  # At Location 6:
  elif i == 5:
    sumL_LOx = float(wks.acell('B37').value) # Sum of the length of plumbing (m)
    sumH_LOx = float(wks.acell('D38').value) # Sum of the changes in height of plumbing (m)
    o_couplings = float(wks.acell('D39').value) # Total couplings up to location LOx
    o_90s = float(wks.acell('D40').value) # Total 90° bends up to location LOx (R/D > 1)
    o_teethrough = float(wks.acell('D41').value) # Number of tee-through fittings LOx (does not account for tube couplings)
    sumL_K = float(wks.acell('C37').value) # Sum of the length of plumbing Ker (m)
    sumH_K = float(wks.acell('E38').value) # Sum of the changes in height of plumbing Ker (m)
    k_couplings = float(wks.acell('E39').value) # Total couplings up to location Ker
    k_90s = float(wks.acell('E40').value) # Total 90° bends up to location Ker (R/D > 1)
    k_teethrough = float(wks.acell('E41').value) # Number of tee-through fittings Ker (does not account for tube couplings)
  
  #-----------------------------------------------------------------
  
  #CONASTANT/DETERMINED
  
  g = 9.80665; # Gravitatinal acceleration (m/s^2)
  
  odImp = 0.5; # Stainless tubing outer diameter (inches)
  wallThicc = 0.035; # Tubing wall thickness (inches)
  
  idImp = odImp-(2*wallThicc); # Stainless tubing inner Diameter (inches)
  
  o_mfr = 1.0556; # Mass flow rate oxidizer (lbm/s)
  k_mfr =  1.2599; # Mass flow rate kerosene + Film Cooling) (lbm/s)

  kDen = 810; # Kerosene density @ 20 degrees C (kg/m^3)
  oDen = 1140; # LOX density @ ~ -200 degrees C (kg/m^3)

  k_mu = .192*10**(-3); # Dynamic viscosity of kerosene @ 20 degrees C (Ns/m^2 or Pa*s)
  o_mu = 6.95*10**(-6); # Dynamic viscosity of LOX @ -183 degrees C (N*s/m^2 or Pa*s)
  
  o_SG = 1.143; # LOx specific gravity (Unitless)
  k_SG = 0.810; # Kerosene specific gravity (Unitless)
  
  cv_check = 1.68; # Coefficient Volume for chosen Check Valve (Unknown?)
  cv_valve = 7.5; # Coefficient Volume for chosen Main Valves (Unknown?)
  
  orifice_drop = 30; # Designed optimal orifice pressure drop (PSI)
  cc_pressure = 250; # Chamber pressure (psig)
  injector_drop = 100; # Injector pressure drop (PSI)
  cooling_drop = 10; # Regenetive cooling drop (PSI)
  
  ssr = 0.002; # Stainless steel roughness (mm)
  
  #-----------------------------------------------------------------
  
  #BASIC CALCULATIONS/CONVERTING UNITS
  
  idMet = idImp/39.3700787; # Stainess tubing inner diameter (meters)
  
  o_mfrMET = o_mfr*0.45359237; # Mass flow rate oxidizer (kg/s)
  k_mfrMET = k_mfr*0.45359237; # Mass flow rate fuel (kg/s)
  
  o_vfr = o_mfrMET/oDen*15850.323141; # volumetric flow rate oxidizer (GPM)
  k_vfr = k_mfrMET/kDen*15850.323141; # volumetric FLow Rate fuel (GPM)
  
  ssrr = ssr/(idMet*1000); # Stainless Steel Relative Roughness (Roughness/Diameter) (Unitless)
  
  A = math.pi*(idMet/2)**2; # Tubing area (meters^2)
  
  vo = o_mfrMET/(oDen * A); # Velocity of LOX in tubing (m/s)
  vk = k_mfrMET/(kDen * A); # Velocity of Kerosene in tubing (m/s)

  k_Reyn = (kDen*vk*idMet)/k_mu; # Reynolds number for Kerosene (Unitless)
  o_Reyn = (oDen*vo*idMet)/o_mu; # Reynolds number for LOX (Unitless)
  
  #-----------------------------------------------------------------
  
  #COLEBROOK EQUATION CALCULATIONS(TO GET FRICTION FACTOR)

  #LOx Side
  iter = 1
  xl = 0.000000001
  xu = 0.1
  
  while iter < 100:
    xr = (xl+xu)/2
    fxl = -2*math.log(((ssrr)/3.7) + (2.51/(o_Reyn*(xl**0.5))),10)*(xl**0.5) - 1
    fxu = -2*math.log(((ssrr)/3.7) + (2.51/(o_Reyn*(xu**0.5))),10)*(xu**0.5) - 1
    fxr = -2*math.log(((ssrr)/3.7) + (2.51/(o_Reyn*(xr**0.5))),10)*(xr**0.5) - 1
    
    if fxl * fxr < 0:
      xu = xr
    elif fxu * fxr < 0:
      xl = xr 
  
    iter = iter + 1
  
  ff_o = round(xr, 5) # Friction factor of LOx


  # Kerosene side:
  iter = 1
  xl = 0.000000001 # Lower bound on Moody chart (close to 0)
  xu = 0.1 # Upper bound on Moody chart
  
  while iter < 100:
    xr = (xl+xu)/2
    fxl = -2*math.log(((ssrr)/3.7) + (2.51/(k_Reyn*(xl**0.5))),10)*(xl**0.5) - 1
    fxu = -2*math.log(((ssrr)/3.7) + (2.51/(k_Reyn*(xu**0.5))),10)*(xu**0.5) - 1
    fxr = -2*math.log(((ssrr)/3.7) + (2.51/(k_Reyn*(xr**0.5))),10)*(xr**0.5) - 1
    
    if fxl * fxr < 0:
      xu = xr
    elif fxu * fxr < 0:
      xl = xr 
  
    iter = iter + 1
  
  ff_k = round(xr, 5) # Friction factor of Kerosene
  
  #-----------------------------------------------------------------
  
  #CALCULATING K VALUES FOR FITTING AND VALVES USING 2K METHOD
  
  #The diameter used in this is imperial for a reason, it's required for this method
  
  sumK_LOx = 0.04*o_couplings + ((200/o_Reyn)+0.1*(1+(1/idImp)))*o_teethrough + ((800/o_Reyn)+0.2*(1+(1/idImp)))*o_90s

  sumK_K = 0.04*k_couplings + ((200/o_Reyn)+0.1*(1+(1/idImp)))*k_teethrough + ((800/o_Reyn)+0.2*(1+(1/idImp)))*k_90s
    
  #-----------------------------------------------------------------
  
  #HEAD LOSS CONSTANTS
  
  HmajLOx_const = (ff_o*vo**2)/(2*g*idMet) # Head loss major constant LOx (Unitless)
  HminLOx_const = (vo**2)/(2*g) # Head loss minor constant LOx (meters)
  
  HmajK_const = (ff_k*vk**2)/(2*g*idMet) # Head loss constant Kerosene (Unitless)
  HminK_const = (vk**2)/(2*g) # Head loss minor constant Kerosene (meters)
  
  #-----------------------------------------------------------------
  
  #CALCULATING PRESSURE LOSS
  
  deltaP_Lox[i] = round(o_vfr**2*o_SG*(1/cv_check**2+1/cv_valve**2)+orifice_drop+(oDen*g)/6894.76*(sumH_LOx+(HmajLOx_const*sumL_LOx)+(HminLOx_const*sumK_LOx)),2) # Pressure loss for LOx (PSI)

  deltaP_K[i] = round(k_vfr**2*k_SG*(1/cv_check**2+1/cv_valve**2)+orifice_drop+cooling_drop+(kDen*g)/6894.76*(sumH_K + (HmajK_const*sumL_K)+(HminK_const*sumK_K)),2) #Pressure loss for Kerosene (PSI)

  #-----------------------------------------------------------------

  #DISPLAY OUTPUTS ON GOOGLE SHEETS AND CONSOLE
  print("total O pressure loss at "+ str(i+1) + ": " + str(round(deltaP_Lox[i])) + " psi")
  print("total K pressure loss at "+ str(i+1) + ": " + str(round(deltaP_K[i])) + " psi")

  o_length[i] = round(sumL_LOx,5)
  k_length[i] = round(sumL_K,5)

LOxTank_press = cc_pressure+injector_drop+math.ceil(deltaP_Lox[5]) # Calculate LOx tank pressure
KerTank_press = cc_pressure+injector_drop+math.ceil(deltaP_K[5]) # Calculate Ker tank pressure
print("tank O pressure: ", LOxTank_press)
print("tank K pressure: ", KerTank_press)

o_pressure = [0,0,0,0,0,0]
k_pressure = [0,0,0,0,0,0]
for i in range(6):
  o_pressure[i] = round(LOxTank_press - deltaP_Lox[i],2)
  k_pressure[i] = round(KerTank_press - deltaP_K[i],2)
  print("O pressure at "+ str(i+1) + ": " + str(round(o_pressure[i])) + " psi")
  print("K pressure at "+ str(i+1) + ": " + str(round(k_pressure[i])) + " psi")

wks.update('G2:L5', [[1,2,3,4,5,6],o_length,o_pressure,deltaP_Lox])
wks.update('G7', LOxTank_press)
wks.update('P2:U5', [[1,2,3,4,5,6],k_length,k_pressure,deltaP_K])
wks.update('P7', KerTank_press)
